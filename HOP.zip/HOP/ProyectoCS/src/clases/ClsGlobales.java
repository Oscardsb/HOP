/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases;

import entidades.Usuario;
import formularios.IFrmUsuarios;
import formularios.MDIPrincipal;


/**
 *
 * @author RYZEN5
 */
public class ClsGlobales {
    public static Usuario usesion = new Usuario();
    public static IFrmUsuarios fusuarios = new IFrmUsuarios();
   
    public static MDIPrincipal fprincipal = new MDIPrincipal();
    
    
}
